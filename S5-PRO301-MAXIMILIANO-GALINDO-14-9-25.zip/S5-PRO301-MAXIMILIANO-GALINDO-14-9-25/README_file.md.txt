# El Faro - Periódico Digital

Un periódico digital moderno desarrollado con Bootstrap 5 y JavaScript vanilla.

## Características

- Diseño responsivo: Compatible con dispositivos móviles, tablets y escritorio  
- Secciones dinámicas: Inicio, Deportes, Negocios y Contacto  
- Gestión de artículos: Agregar, visualizar y eliminar artículos  
- Navegación intuitiva: Sidebar con navegación rápida y breadcrumbs  
- Actualizaciones en tiempo real: Contadores automáticos y fecha/hora  
- Validación de formularios: Validación HTML5 integrada  

## Estructura del Proyecto

```
el-faro/
├── index.html              # Página principal
├── README.md              # Documentación
├── assets/
│   ├── css/
│   │   └── style.css      # Estilos personalizados
│   ├── js/
│   │   └── main.js        # JavaScript principal
│   └── images/
│       └── logo.jpg       # Logo del sitio
└── docs/
    └── estructura.md      # Documentación técnica
```

## Tecnologías Utilizadas

- HTML5: Estructura semántica  
- CSS3: Estilos personalizados con variables CSS  
- Bootstrap 5.3: Framework CSS para diseño responsivo  
- JavaScript ES6+: Funcionalidad interactiva  
- Bootstrap Icons: Iconografía  
- Google Fonts: Tipografías (Roboto, Open Sans)  

## Instalación

1. Descarga o clona este repositorio  
2. Abre el archivo `index.html` en tu navegador  
3. No requiere servidor web para funcionar localmente  

## Funcionalidades

### Secciones disponibles

1. Inicio: Noticias generales con artículos destacados y secundarios  
2. Deportes: Artículos deportivos por categorías  
3. Negocios: Noticias de negocios y economía  
4. Contacto: Formulario de contacto con validación  

### Características técnicas

- Navegación SPA (Single Page Application)  
- Almacenamiento en memoria de artículos  
- Sistema de contadores automáticos  
- Animaciones CSS suaves  
- Validación de formularios en tiempo real  

## Personalización

### Colores

Las variables CSS pueden modificarse en `assets/css/style.css`:

```css
:root {
    --primary-red: #dc3545;
    --dark-gray: #212529;
    --light-gray: #f8f9fa;
}
```

### Agregar nuevas secciones

1. Agregar configuración en `sectionConfig` en `main.js`  
2. Crear la sección HTML correspondiente  
3. Implementar funciones de renderizado si es necesario  

## Compatibilidad

- Chrome 60+  
- Firefox 55+  
- Safari 12+  
- Edge 79+  

## Autor

Desarrollado como proyecto académico de periódico digital.  

## Licencia

Proyecto educativo - Uso libre para fines académicos.  

---

Repositorio: [Semana5-trabajo](https://github.com/Souless-maker/Semana5-trabajo)

