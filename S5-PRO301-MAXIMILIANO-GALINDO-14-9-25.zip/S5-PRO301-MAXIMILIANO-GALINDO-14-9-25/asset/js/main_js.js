// Configuración de secciones mejorada
const sectionConfig = {
    'inicio': { 
        title: 'Noticias Generales', 
        breadcrumb: 'Noticias Generales',
        icon: 'bi-newspaper'
    },
    'deporte': { 
        title: 'Deportes', 
        breadcrumb: 'Deportes',
        icon: 'bi-trophy'
    },
    'negocios': { 
        title: 'Negocios', 
        breadcrumb: 'Negocios',
        icon: 'bi-briefcase'
    },
    'contacto': { 
        title: 'Contacto', 
        breadcrumb: 'Contacto',
        icon: 'bi-envelope'
    }
};

// Arrays para almacenar artículos
let articulosInicio = [];
let articulosDeporte = [];
let articulosNegocios = [];

// Función mejorada para mostrar secciones
function showSection(sectionName) {
    // Ocultar todas las secciones
    document.querySelectorAll('section').forEach(section => {
        section.classList.add('d-none');
    });
    
    // Mostrar sección seleccionada
    const targetSection = document.getElementById(sectionName);
    if (targetSection) {
        targetSection.classList.remove('d-none');
        targetSection.classList.add('active-section');
    }
    
    // Actualizar navbar principal
    document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
        link.classList.remove('active');
    });
    const activeNavLink = document.querySelector(`[onclick="showSection('${sectionName}')"]`);
    if (activeNavLink && activeNavLink.classList.contains('nav-link')) {
        activeNavLink.classList.add('active');
    }
    
    // Actualizar sidebar navigation
    document.querySelectorAll('.quick-nav').forEach(link => {
        link.classList.remove('active');
    });
    const sidebarLink = document.querySelector(`[data-section="${sectionName}"]`);
    if (sidebarLink) {
        sidebarLink.classList.add('active');
    }
    
    // Actualizar breadcrumbs
    updateBreadcrumbs(sectionName);
    
    // Actualizar contadores en sidebar
    updateSidebarCounters();
}

// Función para actualizar breadcrumbs
function updateBreadcrumbs(sectionName) {
    const breadcrumbCurrent = document.getElementById('breadcrumb-current');
    if (breadcrumbCurrent && sectionConfig[sectionName]) {
        breadcrumbCurrent.textContent = sectionConfig[sectionName].breadcrumb;
    }
}

// Función para actualizar contadores en sidebar
function updateSidebarCounters() {
    // Contador inicio
    const inicioCount = document.querySelectorAll('#articulos-destacados-inicio .card, #articulos-secundarios-inicio .card').length;
    const sidebarInicio = document.getElementById('sidebar-contador-inicio');
    if (sidebarInicio) sidebarInicio.textContent = inicioCount;
    
    // Contador deporte
    const deporteCount = document.querySelectorAll('#articulos-deporte .card').length;
    const sidebarDeporte = document.getElementById('sidebar-contador-deporte');
    if (sidebarDeporte) sidebarDeporte.textContent = deporteCount;
    
    // Contador negocios
    const negociosCount = document.querySelectorAll('#articulos-negocios .card').length;
    const sidebarNegocios = document.getElementById('sidebar-contador-negocios');
    if (sidebarNegocios) sidebarNegocios.textContent = negociosCount;
}

// Función para actualizar contadores principales
function actualizarContador(seccion) {
    const contadorElement = document.getElementById(`contador-${seccion}`);
    let cantidad = 0;
    
    switch(seccion) {
        case 'inicio':
            cantidad = articulosInicio.length;
            break;
        case 'deporte':
            cantidad = articulosDeporte.length;
            break;
        case 'negocios':
            cantidad = articulosNegocios.length;
            break;
    }
    
    if (contadorElement) {
        contadorElement.textContent = `${cantidad} artículo${cantidad !== 1 ? 's' : ''}`;
    }
    
    // Actualizar también sidebar
    updateSidebarCounters();
}

// Función para crear artículo mejorada
function crearArticulo(titulo, descripcion, categoria, seccion, tipo = 'normal') {
    const articulo = {
        id: Date.now() + Math.random(),
        titulo,
        descripcion,
        categoria,
        fecha: new Date().toLocaleDateString('es-CL'),
        hora: new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }),
        tipo
    };

    // Agregar al array correspondiente
    switch(seccion) {
        case 'inicio':
            articulosInicio.push(articulo);
            break;
        case 'deporte':
            articulosDeporte.push(articulo);
            break;
        case 'negocios':
            articulosNegocios.push(articulo);
            break;
    }

    renderizarArticulos(seccion);
    actualizarContador(seccion);
}

// Función para renderizar artículos mejorada
function renderizarArticulos(seccion) {
    let articulos, containerDestacados, containerSecundarios;
    
    switch(seccion) {
        case 'inicio':
            articulos = articulosInicio;
            containerDestacados = document.getElementById('articulos-destacados-inicio');
            containerSecundarios = document.getElementById('articulos-secundarios-inicio');
            break;
        case 'deporte':
            articulos = articulosDeporte;
            containerDestacados = document.getElementById('articulos-deporte');
            break;
        case 'negocios':
            articulos = articulosNegocios;
            containerDestacados = document.getElementById('articulos-negocios');
            break;
    }

    if (seccion === 'inicio') {
        // Para inicio, separar destacados y secundarios
        const destacados = articulos.slice(0, 3);
        const secundarios = articulos.slice(3);
        
        if (containerDestacados) {
            containerDestacados.innerHTML = destacados.map(articulo => crearTarjetaHTML(articulo, 'destacado')).join('');
        }
        
        if (containerSecundarios) {
            containerSecundarios.innerHTML = secundarios.map(articulo => crearTarjetaHTML(articulo, 'secundario')).join('');
        }
    } else {
        // Para otras secciones, todos son del mismo tamaño
        if (containerDestacados) {
            containerDestacados.innerHTML = articulos.map(articulo => crearTarjetaHTML(articulo, 'normal')).join('');
        }
    }
}

// Función para crear HTML de tarjeta mejorada
function crearTarjetaHTML(articulo, tipo) {
    const colClass = tipo === 'destacado' ? 'col-lg-4 col-md-6 col-sm-12' : 
                     tipo === 'secundario' ? 'col-lg-3 col-md-4 col-sm-6' : 
                     'col-lg-4 col-md-6 col-sm-12';
    
    const cardClass = tipo === 'destacado' ? 'h-100 border-danger shadow' :
                     tipo === 'secundario' ? 'h-100 shadow-sm' :
                     'h-100 shadow';

    return `
        <div class="${colClass} mb-4">
            <div class="card ${cardClass} position-relative">
                <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
                    <span class="badge bg-light text-dark">${articulo.categoria}</span>
                    <button class="btn btn-sm btn-outline-light opacity-75" onclick="eliminarArticulo('${articulo.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
                <div class="card-body">
                    <h5 class="card-title ${tipo === 'secundario' ? 'fs-6' : ''}">${articulo.titulo}</h5>
                    <p class="card-text text-muted ${tipo === 'secundario' ? 'small' : ''}">${articulo.descripcion}</p>
                </div>
                <div class="card-footer text-muted small">
                    <i class="bi bi-calendar me-1"></i>${articulo.fecha}
                    <i class="bi bi-clock ms-2 me-1"></i>${articulo.hora}
                </div>
            </div>
        </div>
    `;
}

// Función para eliminar artículo
function eliminarArticulo(id) {
    // Buscar y eliminar del array correspondiente
    articulosInicio = articulosInicio.filter(a => a.id != id);
    articulosDeporte = articulosDeporte.filter(a => a.id != id);
    articulosNegocios = articulosNegocios.filter(a => a.id != id);
    
    // Re-renderizar todas las secciones
    renderizarArticulos('inicio');
    renderizarArticulos('deporte');
    renderizarArticulos('negocios');
    
    // Actualizar contadores
    actualizarContador('inicio');
    actualizarContador('deporte');
    actualizarContador('negocios');
}

// Event listeners para formularios
document.addEventListener('DOMContentLoaded', function() {
    // Fecha y hora
    function actualizarFechaHora() {
        const ahora = new Date();
        const fechaElement = document.getElementById('fecha-actual');
        const horaElement = document.getElementById('hora-actual');
        
        if (fechaElement) {
            fechaElement.textContent = ahora.toLocaleDateString('es-CL', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
        
        if (horaElement) {
            horaElement.textContent = ahora.toLocaleTimeString('es-CL');
        }
    }
    
    actualizarFechaHora();
    setInterval(actualizarFechaHora, 1000);

    // Formulario de inicio
    const formInicio = document.getElementById('form-articulo-inicio');
    if (formInicio) {
        formInicio.addEventListener('submit', function(e) {
            e.preventDefault();
            if (formInicio.checkValidity()) {
                const titulo = document.getElementById('titulo-inicio').value;
                const descripcion = document.getElementById('descripcion-inicio').value;
                const categoria = document.getElementById('categoria-inicio').value;
                
                crearArticulo(titulo, descripcion, categoria, 'inicio');
                formInicio.reset();
                formInicio.classList.remove('was-validated');
            } else {
                formInicio.classList.add('was-validated');
            }
        });
    }

    // Formulario de deporte
    const formDeporte = document.getElementById('form-articulo-deporte');
    if (formDeporte) {
        formDeporte.addEventListener('submit', function(e) {
            e.preventDefault();
            if (formDeporte.checkValidity()) {
                const titulo = document.getElementById('titulo-deporte').value;
                const descripcion = document.getElementById('descripcion-deporte').value;
                const categoria = document.getElementById('deporte-categoria').value;
                
                crearArticulo(titulo, descripcion, categoria, 'deporte');
                formDeporte.reset();
                formDeporte.classList.remove('was-validated');
            } else {
                formDeporte.classList.add('was-validated');
            }
        });
    }

    // Formulario de negocios
    const formNegocios = document.getElementById('form-articulo-negocios');
    if (formNegocios) {
        formNegocios.addEventListener('submit', function(e) {
            e.preventDefault();
            if (formNegocios.checkValidity()) {
                const titulo = document.getElementById('titulo-negocios').value;
                const descripcion = document.getElementById('descripcion-negocios').value;
                const categoria = document.getElementById('negocio-categoria').value;
                
                crearArticulo(titulo, descripcion, categoria, 'negocios');
                formNegocios.reset();
                formNegocios.classList.remove('was-validated');
            } else {
                formNegocios.classList.add('was-validated');
            }
        });
    }

    // Formulario de contacto
    const formContacto = document.getElementById('form-contacto');
    if (formContacto) {
        formContacto.addEventListener('submit', function(e) {
            e.preventDefault();
            if (formContacto.checkValidity()) {
                alert('¡Mensaje enviado correctamente!');
                formContacto.reset();
                formContacto.classList.remove('was-validated');
            } else {
                formContacto.classList.add('was-validated');
            }
        });
    }

    // Inicializar contadores
    actualizarContador('inicio');
    actualizarContador('deporte');
    actualizarContador('negocios');
});